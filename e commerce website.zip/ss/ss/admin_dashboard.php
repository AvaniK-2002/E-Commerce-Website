<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'login_register');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session for CSRF protection
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Pagination setup
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Ensure page is at least 1
$offset = ($page - 1) * $limit;

// Fetch products for display with pagination
$stmt = $conn->prepare("SELECT * FROM products LIMIT ?, ?");
$stmt->bind_param("ii", $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();

// Count total products for pagination
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM products");
$totalProducts = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalProducts / $limit);

// Handle adding a new product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['product_image'], $_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    $productName = htmlspecialchars(trim($_POST['product_name']));
    $productPrice = htmlspecialchars(trim($_POST['product_price']));
    $categoryId = intval($_POST['category_id']);
    $productImage = $_FILES['product_image'];

    // Validate inputs
    if (!empty($productName) && is_numeric($productPrice) && $productPrice > 0 && $categoryId > 0) {
        $allowedTypes = ['image/jpeg', 'image/png'];
        $maxSize = 2 * 1024 * 1024; // 2MB

        if (in_array($productImage['type'], $allowedTypes) && $productImage['size'] <= $maxSize) {
            $imageName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', basename($productImage['name']));
            $targetDir = 'uploads/';
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $targetFile = $targetDir . $imageName;

            if (move_uploaded_file($productImage['tmp_name'], $targetFile)) {
                $stmt = $conn->prepare("INSERT INTO products (name, price, image, category_id) VALUES (?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("sssi", $productName, $productPrice, $imageName, $categoryId);
                    if ($stmt->execute()) {
                        echo "<p>Product added successfully!</p>";
                    } else {
                        echo "<p>Error adding product: " . $stmt->error . "</p>";
                    }
                    $stmt->close();
                } else {
                    echo "<p>Error preparing statement: " . $conn->error . "</p>";
                }
            } else {
                echo "<p>Failed to upload image. Check directory permissions.</p>";
            }
        } else {
            echo "<p>Invalid file type or size exceeded.</p>";
        }
    } else {
        echo "<p>Invalid product data.</p>";
    }
}

// Handle deleting a product
if (isset($_POST['delete_product'], $_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    $productId = intval($_POST['product_id']);
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $productId);
        if ($stmt->execute()) {
            echo "<p>Product deleted successfully!</p>";
        } else {
            echo "<p>Error deleting product: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        echo "<p>Error preparing statement: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
        }

        .topbar {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }

        .toggle-menu {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 30px;
            height: 25px;
            color: white;
            size: 30px;
        }

        .bar {
            background-color: white;
            height: 3px;
            border-radius: 2px;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: #2196f3;
            position: fixed;
            top: 0;
            left: -200px;
            transition: left 0.3s ease;
            z-index: 1000;
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }

        .sidebar a:hover {
            background-color: #4caf50;
        }

        .main {
            margin-left: 0;
            transition: margin-left 0.3s ease;
            padding: 20px;
        }

        .main.shifted {
            margin-left: 200px;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .product-item {
            background-color: #f9f9f9;
            padding: 10px;
            border: 1px solid #ddd;
            width: 200px;
            text-align: center;
        }

        .product-item img {
            max-width: 100%;
            height: auto;
        }

        form {
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <button class="toggle-menu" onclick="toggleSidebar()">
            Menu
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </button>
        <h1>Admin Dashboard</h1>
    </div>

    <div class="sidebar" id="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_products.php">Manage Products</a>
        <a href="orders.php">Orders</a>
        <a href="settings.php">Settings</a>
        <a href="index.php">Logout</a>
    </div>

    <div class="main" id="main-content">
        <h2>Add New Product</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="product_name">Product Name:</label><br>
            <input type="text" name="product_name" id="product_name" required><br>

            <label for="product_price">Product Price:</label><br>
            <input type="number" step="0.01" name="product_price" id="product_price" required><br>

            <label for="product_image">Product Image:</label><br>
            <input type="file" name="product_image" id="product_image" required><br>

            <label for="category">Category:</label><br>
            <select name="category_id" id="category" required>
                <?php
                $categories = $conn->query("SELECT * FROM categories");
                while ($category = $categories->fetch_assoc()) {
                    echo "<option value='{$category['id']}'>{$category['name']}</option>";
                }
                ?>
            </select><br>

            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <button type="submit">Add Product</button>
        </form>

        <h2>Product List</h2>
        <div class="product-grid">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="product-item">
                    <img src="uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                    <h4><?php echo $row['name']; ?></h4>
                    <p>$<?php echo $row['price']; ?></p>
                    <form action="" method="post">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <button type="submit" name="delete_product">Delete</button>
                    </form>
                </div>
            <?php } ?>
        </div>

        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            <?php } ?>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const main = document.getElementById('main-content');
            sidebar.classList.toggle('open');
            main.classList.toggle('shifted');
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
