<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="book">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Styles -->
    <link rel="stylesheet" href="styles/bootstrap4/bootstrap.min.css">
    <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/main_styles.css">
</head>
<body>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .top_nav, .main_nav_container {
            background-color: #333;
            color: white;
        }

        .top_nav .top_nav_left {
            padding: 10px 0;
        }

        .navbar_user i {
            color: white;
        }

        /* Booking Section */
        #booking1 {
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f8f9fa;
            padding: 20px;
            margin-top: 20px;
        }

        .form-control {
            margin-bottom: 10px;
        }
    </style>

    <div class="super_container">

        <!-- Header -->
        <header class="header trans_300">
            <!-- Top Navigation -->
            <div class="top_nav">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="top_nav_left">Free shipping on all orders</div>
                        </div>
                        <div class="col-md-6 text-right">
                            <div class="top_nav_right">
                                <ul class="top_nav_menu">
                                    <li class="account">
                                        <a href="#">My Account <i class="fa fa-angle-down"></i></a>
                                        <ul class="account_selection">
                                            <li><a href="logout.php"><i class="fa fa-sign-in"></i>Sign In</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Navigation -->
            <div class="main_nav_container">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                            <div class="logo_container">
                                <a href="#">Purple<span>Star</span></a>
                            </div>
                            <nav class="navbar">
                                <ul class="navbar_menu">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="categories.php">Shop</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                                <ul class="navbar_user">
                                    <li><a href="#"><i class="fa fa-user"></i></a></li>
                                    <li class="checkout">
                                        <a href="#"><i class="fa fa-shopping-cart"></i><span id="checkout_items" class="checkout_items">0</span></a>
                                    </li>
                                </ul>
                                <div class="hamburger_container">
                                    <i class="fa fa-bars"></i>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Cart Section -->
        <div class="container mt-5">
            <h2>Your Cart</h2>
            <div class="row">
                <div class="col-md-8">
                    <div id="cart-items-container" class="cart-items-container">
                        <!-- Dynamically generated cart items will appear here -->
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="order-summary">
                        <h4>Order Summary</h4>
                        <p class="total-price"><strong>Total: $0.00</strong></p>
                        <button id="checkoutButton" class="btn btn-primary mt-3">Proceed to Checkout</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Booking Section -->
        <div class="container mt-5" id="booking1" style="display:none;">
            <h2>Booking Details</h2>
            <form id="bookingForm">
                <input type="text" class="form-control" id="name" placeholder="Enter your name" required>
                <input type="email" class="form-control" id="email" placeholder="Enter your email" required>
                <input type="text" class="form-control" id="phone" placeholder="Enter your phone number" required>
                <textarea class="form-control" id="address" rows="3" placeholder="Enter your address" required></textarea>
                <button id="proceedToPayButton" class="btn btn-success mt-3">Proceed to Pay</button>
            </form>
        </div>

    </div>

    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="styles/bootstrap4/bootstrap.min.js"></script>
    <script>
        // Toggle Booking Section
        document.getElementById('checkoutButton').addEventListener('click', function () {
            document.querySelector('.container.mt-5').style.display = 'none';
            document.getElementById('booking1').style.display = 'block';
        });

        // Proceed to Payment Button
        document.getElementById('proceedToPayButton').addEventListener('click', function () {
            alert('Proceeding to payment...');
        });

        // Razorpay Integration
        const razorpayOptions = {
            "key": "YOUR_RAZORPAY_KEY", // Replace with Razorpay Key
            "amount": 50000, // Amount in paisa (50000 = 500 INR)
            "currency": "INR",
            "name": "Purple Star",
            "description": "Order Payment",
            "handler": function (response) {
                alert("Payment successful. Payment ID: " + response.razorpay_payment_id);
            },
            "prefill": {
                "name": "",
                "email": "",
                "contact": ""
            },
            "theme": {
                "color": "#007bff"
            }
        };

        document.getElementById('proceedToPayButton').addEventListener('click', function () {
            const rzp = new Razorpay(razorpayOptions);
            rzp.open();
        });
    </script>
</body>
</html>
